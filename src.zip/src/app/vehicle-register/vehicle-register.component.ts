import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vehicle-register',
  templateUrl: './vehicle-register.component.html',
  styleUrls: ['./vehicle-register.component.css']
})
export class VehicleRegisterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
