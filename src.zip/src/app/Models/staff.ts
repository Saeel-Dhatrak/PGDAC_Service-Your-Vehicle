export class Staff {
    staffId:number
    name:string
    username:string
    password:string
    phoneNumber:string
    constructor(){}
}
