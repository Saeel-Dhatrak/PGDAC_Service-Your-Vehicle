export class Customer {
    customerId:number
    name:string
    username:string
    password:string
    phoneNumber:string
    address:string
    constructor(){}
}
