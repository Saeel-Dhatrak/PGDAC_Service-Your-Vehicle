export class Admin {
    adminId:number
    name:string
    username:string
    password:string
    phoneNumber:string
    constructor(){}
}
