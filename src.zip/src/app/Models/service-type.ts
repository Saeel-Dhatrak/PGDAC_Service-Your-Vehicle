import { Customer } from "./customer"

export class ServiceType {
    serviceId:number
    price:number
    type:string
    estimatedTime:number
    constructor(){}
    
}
