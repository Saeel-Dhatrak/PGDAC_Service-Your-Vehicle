import { ServicingType } from './servicing-type';

describe('ServicingType', () => {
  it('should create an instance', () => {
    expect(new ServicingType()).toBeTruthy();
  });
});
